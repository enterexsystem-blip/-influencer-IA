# Ayla — pacote inicial de áudios

Os 10 MP3 foram separados por intenção aproximada a partir dos nomes dos arquivos. As frases em `audio_routes.json` são gatilhos sugeridos, não transcrições confirmadas.

## Pastas
- `01_identidade_nome`: identidade e nome.
- `02_inicio_conversa`: início da conversa.
- `03_contexto_memoria`: contexto e menções a Kyodai.
- `04_ambiente_sensores`: ambiente/sensores.
- `05_afeto_reacoes`: reação calorosa.
- `99_revisar`: áudio sem rótulo claro.

## Roteamento
Transcreva o áudio recebido, compare o texto com as variantes e escolha o MP3 com maior confiança. Abaixo de 0,72, responda pela IA normalmente para evitar áudio fora de contexto. Várias frases podem apontar para o mesmo áudio e um áudio pode ser usado em mais de uma intenção.

Este pacote ainda não está ligado ao backend nem publicado no Render. A integração precisa ser aplicada ao código atual da Ayla e os MP3 precisam estar no serviço.
